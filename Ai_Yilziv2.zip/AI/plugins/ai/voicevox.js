const axios = require("axios");

exports.run = {
   usage: ['voicevox'],
   hidden: ['voix'],
   use: 'text',
   category: 'ai',
   async: async (m, { client, isPrefix, command, Func, text }) => {
      try {
         if (!text) return client.reply(m.chat, `• Example : ${isPrefix + command} おはようございます`, m) 
         client.sendReact(m.chat, '🕒', m.key) 
         
         const { data, status } = await axios.request({
            baseURL: "https://api.itsrose.life",
            url: "/voicevox/synthesis",
            method: 'POST',
            params: {
               apikey: process.env.APIKEY_ROSE,
            },
            data: { speaker: 3, text: text },
            responseType: "arraybuffer",
         });

         if (status === 429) {
            return client.reply(m.chat, '🚩 *Limit Apikey Sudah Habis, Silahkan Hubungi Owner*', m);
         }

         if (status !== 200) {
            return client.reply(m.chat, 'Synthesis Failed', m);
         }

         client.sendMessage(m.chat, { audio: data, ptt: true, mimetype: "audio/mpeg", fileName: "vn.mp3", waveform: [0,3,58,44,35,32,2,4,31,35,44,34,48,13,0,54,49,40,1,44,50,51,16,0,3,40,39,46,3,42,38,44,46,0,0,47, 0,0,46,19,20,48,43,49,0,0,39,40,31,18,29,17,25,37,51,22,37,34,19,11,17,12,16,19] }, { quoted: m });
         await Func.delay(1000);
         client.sendReact(m.chat, '✅', m.key) 
      } catch (e) {
         return client.reply(m.chat, '🚩 *Terjadi Masalah Saat Memproses Voicevox, Hubungi Owner*', m);
      }
   },
   error: false,
   limit: true,
   premium: true, 
   location: __filename
};
