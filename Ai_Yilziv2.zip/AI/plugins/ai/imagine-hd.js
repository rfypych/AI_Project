const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

exports.run = {
   usage: ['imagine-hd'],
   use: 'style_id | size | prompt',
   category: 'ai',
   async: async (m, { client, command, text, Func, isPrefix  }) => {
      try {
         if (!text) return client.reply(m.chat, `*STYLE ID*
        
- 21 = Anime - Hidupkan karakter dan cerita dengan karya seni yang hidup dan ekspresif yang terinspirasi oleh animasi Jepang.
 - 26 = Potret - Menyempurnakan potret ekspresif, menangkap esensi dan kepribadian individu dengan detail.
 - 27 = V1 - Kuasai gaya seni yang mudah beradaptasi: foto-realistis namun serbaguna, memungkinkan ekspresi kreatif tanpa batas.
 - 28 = V3 - Kuasai foto-realisme dengan gaya yang mudah beradaptasi, mencakup beragam ekspresi artistik dengan mudah.
 - 29 = Realistis - Ciptakan visual yang rumit dan nyata dengan tekstur mendetail, menangkap esensi realitas.
 - 30 = V4 - Temukan gaya menguasai foto-realisme, beradaptasi secara mulus dengan beragam genre seni dengan presisi.
 - 31 = V4 (Kreatif) - Gabungkan fotorealisme dengan seni imajinatif dan mudah beradaptasi di berbagai genre.
 - 32 = V4.1 - Seni serbaguna yang menggabungkan fotorealisme dengan kreativitas bergaya tanpa batas.
 - 33 = V5 - Gaya seni yang melampaui batas dengan mulus memadukan realisme dan kreativitas tanpa batas.
 - 34 = Anime V5 - Gaya seni yang mengandung anime: dinamis, ekspresif, dan penuh dengan penceritaan yang hidup di setiap goresannya.
 - 122 = SDXL 1.0 - AI inovatif: Potret hiper-realistis, gaya beragam, integrasi teks mulus, komposisi luar biasa.

*SIZE IMAGE*

- 1:1 = Persegi sempurna, ideal untuk tampilan yang seimbang dan seragam.

- 3:2 = Rasio klasik yang menawarkan perspektif yang sedikit lebih luas.

- 4:3 = Tradisional dan serbaguna, memberikan lanskap yang seimbang.

- 3:4 = Berorientasi potret, menekankan detail vertikal secara elegan.

- 16:9 = Kecemerlangan layar lebar, menangkap cakrawala luas dengan mulus.

- 9:16 = Tinggi dan menawan, sempurna untuk mendongeng vertikal.

*PROMPT* = Prompt adalah input teks yang memandu AI dalam menghasilkan konten visual. Ini mendefinisikan deskripsi tekstual atau konsep untuk gambar yang ingin Anda hasilkan. Anggap saja sebagai visi kreatif yang Anda inginkan untuk dihidupkan oleh AI. Membuat petunjuk yang jelas dan kreatif sangat penting untuk mencapai hasil yang diinginkan dengan API Imagine. Misalnya, Hutan yang tenang dengan sungai di bawah sinar bulan, bisa menjadi prompt.

• Example : ${isPrefix + command} 21 | 1:1 | long hair`, m);

         const [style_id, aspect_ratio, prompt] = text.split('|').map(part => part.trim());

         if (!style_id || !aspect_ratio || !prompt) {
            return client.reply(m.chat, Func.example(isPrefix, command, '21 | 1:1 | long hair'), m);
         }
         client.sendReact(m.chat, '🕒', m.key) 
         const response = await generateImage(style_id, aspect_ratio, prompt);

         if (response.status === 200) {
            const imageBuffer = response.data;

            // Simpan gambar ke file
            const fileName = `./media/file/${Date.now()}.png`;
            fs.writeFileSync(fileName, imageBuffer);

            // Kirim gambar
            await client.sendFile(m.chat, fileName, 'result.png', 'Here is your generated image.', m);
            await Func.delay(1000);
            client.sendReact(m.chat, '✅', m.key) 

            // Hapus file setelah dikirim
            fs.unlinkSync(fileName);
         } else {
            console.error(`Status Code: ${response.status}`);
            return client.reply(m.chat, Func.texted('bold', '🚩 Failed to generate image. Please try again later.'), m);
            client.sendReact(m.chat, '❎', m.key) 
         }
      } catch (e) {
         console.error(e);
         return client.reply(m.chat, Func.jsonFormat(e), m);
         client.sendReact(m.chat, '❎', m.key);
      }
   },
   error: false,
   premium: true, 
   location: __filename
};

async function generateImage(style_id, aspect_ratio, prompt) {
   const apiUrl = 'https://api.vyro.ai/v1/imagine/api/generations';
   const apiToken = process.env.IMAGINE_API;

   const headers = {
      'Authorization': `Bearer ${apiToken}`,
      'Content-Type': 'multipart/form-data',
   };

   const formData = new FormData();
   formData.append('prompt', prompt);
   formData.append('style_id', style_id);
   formData.append('aspect_ratio', aspect_ratio);
   formData.append('high_res_results', '1');

   const response = await axios.post(apiUrl, formData, { headers, responseType: 'arraybuffer' });
   return response;
}
