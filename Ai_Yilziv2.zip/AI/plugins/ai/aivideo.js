const fetch = require('node-fetch');

exports.run = {
   usage: ['aivideo'],
   hidden: [''],
   use: 'seconds | prompt',
   category: 'ai',
   async: async (m, { client, Func, command, text, isPrefix }) => {
      try {
         const [seconds, prompt] = text.split('|').map(item => item.trim());
         if (isNaN(seconds) || !prompt) {
            return client.reply(m.chat, Func.texted('bold', `🚩 Invalid usage.
• Example: ${isPrefix + command} 3 | man walking on the road, ultra HD video`), m);
         }

         const apiKey = process.env.STABLED_DIFF;
         const apiUrl = "https://stablediffusionapi.com/api/v5/text2video";
         client.sendReact(m.chat, '🕒', m.key);
         const requestBody = {
            key: apiKey,
            prompt: prompt,
            negative_prompt: "Low Quality",
            scheduler: "UniPCMultistepScheduler",
            seconds: parseInt(seconds)
         };

         const requestOptions = {
            method: 'POST',
            headers: {
               'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody),
            redirect: 'follow'
         };

         const response1 = await fetch(apiUrl, requestOptions);
         const result1 = await response1.json();

         if (result1.status === 'success' && result1.output && result1.output.length > 0) {
            const videoUrl = result1.output[0];
            client.sendFile(m.chat, videoUrl, 'output_video.mp4', '', m);
         } else if (result1.status === 'processing') {
           return client.reply(m.chat, `🔄 *PROCESS VIDEO*

Video Sedang Di Proses, Tunggu 1 - 3 Menit
(${result1.future_links})`, m); 
            const delayInSeconds = parseInt(seconds) * 30; // Calculate the delay in seconds
            setTimeout(async () => {
               const videoUrl = result1.future_links;
               client.sendFile(m.chat, videoUrl, 'output_video.mp4', '', m);
               client.sendReact(m.chat, '✅', m.key);
            }, delayInSeconds * 1000); // Convert seconds to milliseconds
         } else {
            return client.reply(m.chat, Func.jsonFormat(result1), m);
         }
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename,
};
