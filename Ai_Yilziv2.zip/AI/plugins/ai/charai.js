const axios = require("axios");

exports.run = {
   usage: ['charai'],
   use: 'text', 
   category: 'ai',
   async: async (m, { client, isPrefix, command, Func, text }) => {
      try {
         if (!text) return client.reply(m.chat, `• Example : ${isPrefix + command} Hello`, m);
         client.sendReact(m.chat, '🕒', m.key);
         
         const { data, status } = await axios.request({
            baseURL: "https://api.itsrose.life",
            url: "/cai/chat",
            method: 'POST',
            params: {
               apikey: process.env.APIKEY_ROSE,
            },
            data: { "character_id": "8bbdf29b-c0aa-4024-8690-bb83d8276832", "message": text, "enable_nsfw": false },
            responseType: "json", // Change responseType to "json"
         });

         if (status === 429) {
            return client.reply(m.chat, '🚩 *Limit Apikey Sudah Habis, Silahkan Hubungi Owner*', m);
         }

         if (status !== 200) {
            return client.reply(m.chat, 'Synthesis Failed', m);
         }

         const responseMessage = data.result?.message || 'Unknown';
         client.reply(m.chat, responseMessage, m);
         await Func.delay(1000);
         client.sendReact(m.chat, '✅', m.key);
      } catch (e) {
         console.error(e);
         return client.reply(m.chat, '🚩 *Terjadi Masalah Saat Memproses Voicevox, Hubungi Owner*', m);
      }
   },
   error: false,
   limit: true,
   premium: true, 
   location: __filename
};

