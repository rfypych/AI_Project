const axios = require('axios');

exports.run = {
   usage: ['img', 'photoleapapp'],
   hidden: [''],
   use: 'prompt',
   category: 'ai',
   async: async (m, { client, args, Func, isPrefix, command, text }) => {
      try {
         if (args.length >= 1) {
            // Handle command with arguments if needed
         } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
         } else {
            return m.reply(Func.example(isPrefix, command, 'cat in thr moon, ultra HD 8K'));
         }

         client.sendReact(m.chat, '🕒', m.key); // Changed emoji to a clock

         let data = await textToImage(text);
         if (data) {
            await client.sendFile(m.chat, data.result_url, '', `Image for ${text}`, m, false, {
               mentions: [m.sender]
            });
         }
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};

async function textToImage(text) {
   try {
      const { data } = await axios.get("https://tti.photoleapapp.com/api/v1/generate?prompt=" + encodeURIComponent(text)); // Encode text parameter
      return data;
   } catch (err) {
      return null;
   }
}

