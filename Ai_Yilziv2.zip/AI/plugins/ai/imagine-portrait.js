const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

exports.run = {
   usage: ['imagine-potrait'],
   use: 'size | prompt',
   category: 'ai',
   async: async (m, { client, command, text, Func, isPrefix  }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, '1:1 | long hair'), m);

         const [aspect_ratio, prompt] = text.split('|').map(part => part.trim());

         if (!aspect_ratio || !prompt) {
            return client.reply(m.chat, Func.example(isPrefix, command, '1:1 | long hair'), m);
         }
         client.sendReact(m.chat, '🕒', m.key) 
         const response = await generateImage(aspect_ratio, prompt);

         if (response.status === 200) {
            const imageBuffer = response.data;

            // Simpan gambar ke file
            const fileName = `./media/file/${Date.now()}.png`;
            fs.writeFileSync(fileName, imageBuffer);

            // Kirim gambar
            await client.sendFile(m.chat, fileName, 'result.png', 'Here is your generated image.', m);
            await Func.delay(1000);
            client.sendReact(m.chat, '✅', m.key) 

            // Hapus file setelah dikirim
            fs.unlinkSync(fileName);
         } else {
            console.error(`Status Code: ${response.status}`);
            return client.reply(m.chat, Func.texted('bold', '🚩 Failed to generate image. Please try again later.'), m);
            client.sendReact(m.chat, '❎', m.key) 
         }
      } catch (e) {
         console.error(e);
         return client.reply(m.chat, Func.jsonFormat(e), m);
         client.sendReact(m.chat, '❎', m.key);
      }
   },
   error: false,
   premium: true, 
   location: __filename
};

async function generateImage(aspect_ratio, prompt) {
   const apiUrl = 'https://api.vyro.ai/v1/imagine/api/generations';
   const apiToken = process.env.IMAGINE_API;

   const headers = {
      'Authorization': `Bearer ${apiToken}`,
      'Content-Type': 'multipart/form-data',
   };

   const formData = new FormData();
   formData.append('prompt', prompt);
   formData.append('style_id', '26');
   formData.append('aspect_ratio', aspect_ratio);
   formData.append('high_res_results', '1');

   const response = await axios.post(apiUrl, formData, { headers, responseType: 'arraybuffer' });
   return response;
}
