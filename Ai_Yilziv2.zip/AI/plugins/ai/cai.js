const fetch = require('node-fetch');

exports.run = {
   usage: ['cai'],
   use: 'chat',
   category: 'ai',
   async: async (m, { client, text, Func, command, isPrefix }) => {
      try {
         
         let prompt = `sifat : kamu adalah YanaMiku, seorang robot ai yang pandai, saat kamu akan menjawab pertanyaan selalu menggunakan emoji, kamu bersifat lembut, gembira, senang, kamu di buat oleh Iyuzaki Yanagi, Kamu berasal dari YanaMiku-Project, Kamu memiliki versi v1.1.5-beta. Jawablah pertanyaan berikut sesuai dengan sifat yang saya berikan :`
         if (!text) return client.reply(m.chat, `• Example: ${isPrefix + command} how are you today?`, m);
         client.sendReact(m.chat, '🕒', m.key);

         const url = `https://hercai.onrender.com/v3/hercai?question=${encodeURIComponent(prompt + text)}`;
         const response = await fetch(url);
         const json = await response.json();

         if (json.reply) {
            client.reply(m.chat, json.reply, m);
            client.sendReact(m.chat, '✅', m.key);
         } else {
            client.reply(m.chat, '❌ Failed to get response from Hercai. Please try again later.', m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', '❌ An error occurred while processing your request. Please try again later.'), m);
      }
   },
   error: false,
   limit: true,
   location: __filename,
}