const fetch = require('node-fetch');

exports.run = {
   usage: ['hercai', 'hercai-v3', 'hercai-v3-32k', 'hercai-turbo', 'hercai-turbo-16k', 'hercai-gemini'],
   use: 'chat',
   category: 'ai',
   async: async (m, { client, text, Func, command }) => {
      try {
         let model;

         if (command === 'hercai') {
            model = 'v3';
         } else if (command === 'hercai-v3') {
            model = 'v3';
         } else if (command === 'hercai-v3-32k') {
            model = 'v3-32k';
         } else if (command === 'hercai-turbo') {
            model = 'turbo';
         } else if (command === 'hercai-turbo-16k') {
            model = 'turbo-16k';
         } else if (command === 'hercai-gemini') {
            model = 'gemini';
         } else {
            return client.reply(m.chat, '❌ Unknown Hercai model. Available models: hercai, hercai-v3, hercai-v3-32k, hercai-turbo, hercai-turbo-16k, hercai-gemini', m);
         }

         if (!text) return client.reply(m.chat, `• Example: ${command} how are you today?`, m);
         client.sendReact(m.chat, '🕒', m.key);

         const url = `https://hercai.onrender.com/${model}/hercai?question=${encodeURIComponent(text)}`;
         const response = await fetch(url);
         const json = await response.json();

         if (json.reply) {
            client.reply(m.chat, json.reply, m);
            client.sendReact(m.chat, '✅', m.key);
         } else {
            client.reply(m.chat, '❌ Failed to get response from Hercai. Please try again later.', m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', '❌ An error occurred while processing your request. Please try again later.'), m);
      }
   },
   error: false,
   limit: true,
   location: __filename,
};

