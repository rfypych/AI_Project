const axios = require("axios");

exports.run = {
   usage: ['cai-search'],
   use: 'text',
   category: 'ai',
   async: async (m, { client, Func, command, text }) => {
      try {
         if (!text) return client.reply(m.chat, `• Example : ${isPrefix + command} Test`, m);

         const apiUrl = "https://api.itsrose.life/cai/search_characters";
         const apiKey = process.env.YOUR_API_KEY; // Ganti dengan kunci API Anda

         const { data, status } = await axios.post(apiUrl, { "query": text }, {
            headers: {
               'Authorization': `Bearer ${apiKey}`,
               'Content-Type': 'application/json',
            },
         });

         if (status !== 200) {
            return client.reply(m.chat, 'Bad Request', m);
         }

         const characters = data.result?.characters || [];
         if (characters.length === 0) {
            return client.reply(m.chat, 'No characters found for the given query.', m);
         }

         const characterList = characters.map(char => {
            return `ID: ${char.character_id}\nName: ${char.name}\nDescription: ${char.description}\nTags: ${char.tags}\n`;
         });

         const responseMessage = `Found Characters:\n\n${characterList.join('\n\n')}`;
         client.reply(m.chat, responseMessage, m);
      } catch (e) {
         console.error(e);
         return client.reply(m.chat, 'Error processing the request. Please try again later.', m);
      }
   },
   error: false,
   limit: true,
   premium: true, 
   location: __filename
};

