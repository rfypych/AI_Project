const fetch = require('node-fetch');
const fs = require('fs');

exports.run = {
  usage: ['aivoice'],
  category: 'ai', 
  async: async (m, { client, text, command }) => {
    try {
      if (!text) return client.reply(m.chat, `Example: ${command} Hallo, aku adalah Iyuzaki Yanagi, salam kenal`, m);
      
      const url = `https://anime-voice-waifu-ai-api.p.rapidapi.com/japaneseto?text=${encodeURIComponent(text)}`;
      const options = {
        method: 'GET',
        headers: {
          'X-RapidAPI-Key': '299cae07damsh832e51b07f04640p174081jsn986cc97aaae8',
          'X-RapidAPI-Host': 'anime-voice-waifu-ai-api.p.rapidapi.com'
        }
      };

      const response = await fetch(url, options);
      const result = await response.text();

      const filePath = 'aivoice.mp3';
      fs.writeFileSync(filePath, result);

      // Send the voice file
      client.sendFile(m.chat, filePath, '', '', m, { ptt: true });

      // Delete the temporary file
      fs.unlinkSync(filePath);
    } catch (e) {
      console.error(e);
      return client.reply(m.chat, 'Error occurred while processing your request', m);
    }
  },
  error: false,
  location: __filename
};