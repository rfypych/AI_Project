const simsimi = require('chats-simsimi');
const gtts = require('gtts');
const fs = require('fs').promises;

exports.run = {
   usage: ['simsimivoice'],
   hidden: 'simivoice', 
   use: 'chat',
   category: 'ai',
   async: async (m, { client, text, isPrefix, command }) => {
      try {
         if (!text) {
            return client.reply(m.chat, `• Example : ${isPrefix + command} Halo, Apa kabar?`, m);
         }
         client.sendReact(m.chat, '🕒', m.key) 
         const response = await simsimi(text, 'id');

         if (response.status && response.result) {
            // Create TTS voice file
            const gttsVoice = new gtts(response.result, 'id');

            // Save the TTS voice as an MP3 file
            const filePath = `./media/mp3/simsimivoice_${Date.now()}.mp3`;
            await new Promise((resolve, reject) => {
               gttsVoice.save(filePath, (err) => {
                  if (err) reject(err);
                  else resolve();
               });
            });

            // Send the TTS voice file
            await client.sendFile(m.chat, filePath, '', 'SimSimiVoice', m, {
               ptt: true
            });
            await Func.delay(1000);
            client.sendReact(m.chat, '✅', m.key) 

            // Remove the generated voice file after sending
            await fs.unlink(filePath);
         } else {
            client.reply(m.chat, 'Failed to get SimSimi response. Please try again later.', m);
         }
      } catch (error) {
         console.error(error);
         client.reply(m.chat, 'An error occurred while processing your request. Please try again later.', m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};
