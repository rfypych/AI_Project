const simsimi = require('chats-simsimi');

exports.run = {
   usage: ['simsimi'],
   hidden: 'simi', 
   use: 'chat',
   category: 'ai', 
   async: async (m, { client, text, isPrefix, command }) => {
      try {
         if (!text) {
            return client.reply(m.chat, `• Example : ${isPrefix + command} Halo, Apa kabar?`, m);
         }

         const response = await simsimi(text, 'id');
         client.sendReact(m.chat, '🟡', m.key) 
         if (response.status && response.result) {
            client.reply(m.chat, `${response.result}`, m);
         } else {
            client.reply(m.chat, 'Failed to get SimSimi response. Please try again later.', m);
         }
      } catch (error) {
         console.error(error);
         client.reply(m.chat, 'An error occurred while processing your request. Please try again later.', m);
      }
   },
   error: false,
   limit: true, 
   location: __filename
};
