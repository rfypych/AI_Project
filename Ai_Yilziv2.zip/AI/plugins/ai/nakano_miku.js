const fetch = require('node-fetch');

exports.run = {
   usage: ['ai-miku'],
   use: 'chat', 
   category: 'ai',
   async: async (m, { client, args }) => {
      try {
         if (!args || args.length === 0) {
            return client.reply(m.chat, 'Silakan masukkan teks atau obrolan yang ingin Anda ajukan kepada Miku.', m);
         }

         const text = args.join(' ');

         const apiUrl = `https://api-charaai.vercel.app/charaai?chara=Miku&text=${encodeURIComponent(text)}`;

         // Mengirim permintaan ke web URL
         const response = await fetch(apiUrl);
         const result = await response.text();

         // Mengirim hasil sebagai pesan
         client.reply(m.chat, result.replace(/\\n/g, '\n'), m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan dalam menjalankan permintaan Anda.', m);
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
}

