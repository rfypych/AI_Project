const fs = require('fs');
const path = require('path');
const getGPT4js = require("gpt4js");

exports.run = {
   usage: ['ai'],
   async: async (m, { client, text, Func }) => {
      try {
         if (!text) return client.reply(m.chat, 'Apa itu kucing?', m);
         let user = global.db.users.find(v => v.jid == m.sender);
         if (m.mtype === 'conversation' || m.mtype === 'extendedTextMessage') {
            client.sendReact(m.chat, '🕘', m.key);

            // Ambil nomor pengguna dari ID pengirim
            let number = m.sender.replace(/@.+/g, '');

            // Tentukan path file untuk riwayat pesan
            const chatDir = path.join('media', 'json', 'chat');
            const chatFile = path.join(chatDir, `${number}.json`);

            // Buat direktori jika belum ada
            if (!fs.existsSync(chatDir)) {
               fs.mkdirSync(chatDir, { recursive: true });
            }

            // Inisialisasi pesan awal
            const initialMessages = [
               { role: "user", content: `Hallo` },
               { role: "assistant", content: `Hallo, ada yang bisa saya bantu hari ini?` }
            ];

            // Muat riwayat pesan jika ada, jika tidak buat array dengan pesan awal
            let messages = [];
            if (fs.existsSync(chatFile)) {
               const data = fs.readFileSync(chatFile, 'utf-8');
               messages = JSON.parse(data);
            } else {
               messages = initialMessages;
               fs.writeFileSync(chatFile, JSON.stringify(messages, null, 2));
            }

            // Tambahkan pesan user ke riwayat
            messages.push({ role: "user", content: text });

            // Inisialisasi GPT4js di dalam fungsi async
            const GPT4js = await getGPT4js();
            const options = {
               provider: "Nextway",
               model: "gpt-4o-free",
            };
            const provider = GPT4js.createProvider(options.provider);

            // Dapatkan respons dari gpt4js
            const response = await provider.chatCompletion(messages, options, (data) => {
               console.log(data);
            });

            // Tambahkan respons assistant ke riwayat
            messages.push({ role: "assistant", content: response });

            // Simpan riwayat pesan yang telah diperbarui ke file
            fs.writeFileSync(chatFile, JSON.stringify(messages, null, 2));

            client.reply(m.chat, response + '\n\n> Response By : YanaMiku.AI Service', m).then(() => client.sendReact(m.chat, '✅', m.key));
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, `Terjadi kesalahan: ${e.message}`, m);
      }
   },
   error: false,
   private: true,
   location: __filename
};
