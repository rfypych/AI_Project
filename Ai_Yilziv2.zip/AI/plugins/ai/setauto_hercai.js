exports.run = {
   usage: ['autohercai'],
   hidden: [''],
   use: 'on / off',
   category: 'ai',
   async: async (m, {
      client,
      Func, 
      args
   }) => {
      try {
         // Your Code
         if (! args[0]) return client.reply(m.chat, '🚩 *Berikan Argumen Berupa Perintah [On / Off]*', m) 
         let user = global.db.users.find(v => v.jid == m.sender);
         if (args[0] === 'on') {
         user.hercai = true;
         client.reply(m.chat, `✅ *Auto Chat Ai Berhasil Dinyalakan*`, m) 
         }
         if (args[0] === 'off') {
         user.hercai = false;
         client.reply(m.chat, `✅ *Auto Chat Ai Berhasil Dimatikan*`, m) 
         }
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}